TODO: names of team members and their contributions to the project
Jiaqi Yu, Lily Ru

MS1: 
Jiaqi Yu: Handle basic command line and reading logics
Lily Ru: Add Validations to the arguments nad inputs; Set up for MS2 and MS3

MS2: 
Lily Ru: Implement cache data structures and LRU replacement logic. verify hit/miss accuracy.
Jiaqi Yu: Implement cycle counting, write policies and assist with testing and debugging.

TODO (for MS3): best cache report